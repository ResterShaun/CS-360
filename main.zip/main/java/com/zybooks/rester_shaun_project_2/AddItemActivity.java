package com.zybooks.rester_shaun_project_2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Shaun Rester CS-360 Final App Project
 * Code to add inventory items
 */
public class AddItemActivity extends AppCompatActivity {

    String EmailHolder, DescHolder, QtyHolder, UnitHolder;
    TextView UserEmail;
    ImageButton IncreaseQty, DecreaseQty;
    EditText ItemDescValue, ItemQtyValue, ItemUnitValue;
    Button CancelButton, AddItemButton;
	Boolean EmptyHolder;
    ItemsSQLiteHandler db;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additem);

        // Initiate buttons, textViews, and editText variables
        UserEmail = findViewById(R.id.LoggedUser);
        ItemDescValue = findViewById(R.id.eT_ItemDescription);
        ItemUnitValue = findViewById(R.id.eT_ItemUnit);
        IncreaseQty = findViewById(R.id.Increase);
        DecreaseQty = findViewById(R.id.Decrease);
        ItemQtyValue = findViewById(R.id.eT_ItemQuantity);
        CancelButton = findViewById(R.id.addCancelButton);
        AddItemButton = findViewById(R.id.addItemButton);
		db = new ItemsSQLiteHandler(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Get user email send by ItemsListActivity
        EmailHolder = intent.get().getStringExtra(ItemsListActivity.UserEmail);

        // Set user email for textViewLoggedUser
        UserEmail.setText(getString(R.string.logged_user, EmailHolder));

        // Add click listener to itemQtyIncrease forgotPasswordButton
        IncreaseQty.setOnClickListener(view -> {
            int input = 0, total;

            String value = ItemQtyValue.getText().toString().trim();

            if (!value.isEmpty()) {
                input = Integer.parseInt(value);
            }

            total = input + 1;
            ItemQtyValue.setText(String.valueOf(total));
        });

        // Add click listener to itemQtyDecrease forgotPasswordButton
        DecreaseQty.setOnClickListener(view -> {
            int input, total;

            String qty = ItemQtyValue.getText().toString().trim();

            if (qty.equals("0")) {
                Toast.makeText(this, "Item Quantity is Zero", Toast.LENGTH_LONG).show();
            } else {
                input = Integer.parseInt(qty);
                total = input - 1;
                ItemQtyValue.setText(String.valueOf(total));
            }
        });

        // Add click listener to addCancelButton
        CancelButton.setOnClickListener(view -> {
            // Going back to ItemsListActivity after cancel adding item
			Intent add = new Intent();
			setResult(0, add);
            this.finish();
        });

        // Add click listener to addItemButton and transfer data to ItemsListActivity
        AddItemButton.setOnClickListener(view -> InsertItemIntoDatabase());
    }

    // Insert item data to DB and transfer data to ItemsListActivity
    public void InsertItemIntoDatabase() {
		String message = CheckEditTextNotEmpty();

        if (!EmptyHolder) {
       	  	String email = EmailHolder;
        	String desc = DescHolder;
        	String qty = QtyHolder;
        	String unit = UnitHolder;

        	Item item = new Item(email, desc, qty, unit);
        	db.createItem(item);

            // Display message post insertion to table
            Toast.makeText(this,"Item Added Successfully", Toast.LENGTH_LONG).show();

            // Terminate AddItemActivity
			Intent add = new Intent();
			setResult(RESULT_OK, add);
            this.finish();
        } else {
            // Display message if item description = void target section
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Verify item description not void
    public String CheckEditTextNotEmpty() {
        // Get/store value from fields to string variable
		String message = "";
        DescHolder = ItemDescValue.getText().toString().trim();
        UnitHolder = ItemUnitValue.getText().toString().trim();
		QtyHolder = ItemQtyValue.getText().toString().trim();

        if (DescHolder.isEmpty()) {
			ItemDescValue.requestFocus();
            EmptyHolder = true;
            message = "Item Description is Empty";
        } else if (UnitHolder.isEmpty()){
			ItemUnitValue.requestFocus();
			EmptyHolder = true;
			message = "Item Unit is Empty";
        } else {
        	EmptyHolder = false;
		}
        return message;
    }

}
