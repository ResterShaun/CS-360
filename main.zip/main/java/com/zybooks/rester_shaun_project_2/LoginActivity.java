package com.zybooks.rester_shaun_project_2;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Shaun Rester CS-360 Final App Project
 * Handles functionality for login page
 * verifying data is properly input/not void for registration
 * Authenticates inputs for our DB
 */
public class LoginActivity extends AppCompatActivity {

	Activity activity;
    Button LoginButton, RegisterButton, ForgotPassButton;
    EditText Email, Password;
    String NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
	PopupWindow popwindow;
    SQLiteDatabase db;
    UsersSQLiteHandler handler;
    String TempPassword = "NOT_FOUND" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;

        LoginButton = findViewById(R.id.signin);
        RegisterButton = findViewById(R.id.register);
        ForgotPassButton = findViewById(R.id.forgotPassword);
        Email = findViewById(R.id.eT_Email);
        Password = findViewById(R.id.eT_Password);
        handler = new UsersSQLiteHandler(this);

        // Add click listener to sign in forgotPasswordButton
        LoginButton.setOnClickListener(view -> {
            // Call Login function
            LoginFunction();
        });

        // Add click listener to register forgotPasswordButton.
        RegisterButton.setOnClickListener(view -> {
            // Open new RegisterActivity using intent on forgotPasswordButton click.
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

		// Add click listener to register forgotPasswordButton.
		ForgotPassButton.setOnClickListener(view -> {
			EmailHolder = Email.getText().toString().trim();

			if (!EmailHolder.isEmpty()) {
				forgotPassPopup();
			} else {
				Toast.makeText(LoginActivity.this, "User Email is Empty", Toast.LENGTH_LONG).show();
			}
		});
    }

    // Login function
    public void LoginFunction() {
		String message = CheckEditTextNotEmpty();

        if(!EmptyHolder) {
            // Open SQLite database write permission
            db = handler.getWritableDatabase();

            // Add search email query to cursor
            Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME, null, " " + UsersSQLiteHandler.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    // Store Password and Name associated with entered email
                    TempPassword = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLiteHandler.COLUMN_4_PASSWORD));
                    NameHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLiteHandler.COLUMN_1_NAME));
                    PhoneNumberHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLiteHandler.COLUMN_2_PHONE_NUMBER));

                    // Close cursor.
                    cursor.close();
                }
            }
			handler.close();

            // Call method to check final result
            CheckFinalResult();
        } else {
            //If login EditText void execute block
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Check editText fields not void
	public String CheckEditTextNotEmpty() {
		// Get value of fields/storing to string variable
		String message = "";
		EmailHolder = Email.getText().toString().trim();
		PasswordHolder = Password.getText().toString().trim();

		if (EmailHolder.isEmpty()){
			Email.requestFocus();
			EmptyHolder = true;
			message = "User Email is Empty";
		} else if (PasswordHolder.isEmpty()){
			Password.requestFocus();
			EmptyHolder = true;
			message = "User Password is Empty";
		} else {
			EmptyHolder = false;
		}
		return message;
	}

    // Check password entered from DB email associated password
    public void CheckFinalResult(){
        if(TempPassword.equalsIgnoreCase(PasswordHolder)) {
            Toast.makeText(LoginActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();

            // Send Name to ItemsListActivity using intent
            Bundle bundle = new Bundle();
            bundle.putString("user_name", NameHolder);
            bundle.putString("user_email", EmailHolder);
            bundle.putString("user_phone", PhoneNumberHolder);

            // Transition to ItemsListActivity after login success message
            Intent intent = new Intent(LoginActivity.this, ItemsListActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);

            // Clear editText  post successful login close DB
            EmptyEditTextAfterDataInsert();
        } else {
            // Display error message for invalid credentials
            Toast.makeText(LoginActivity.this,"Incorrect Email or Password\nor User Not Registered",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }

    // Empty edittext post successful login
    public void EmptyEditTextAfterDataInsert() {
        Email.getText().clear();
        Password.getText().clear();
    }

	public void forgotPassPopup() {
		LayoutInflater inflater = activity.getLayoutInflater();
		View layout = inflater.inflate(R.layout.forgot_pass_popup, activity.findViewById(R.id.popup_element));

		popwindow = new PopupWindow(layout, 800, 800, true);
		popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

		EditText phone = layout.findViewById(R.id.eT_ItemDescriptionTab);
		TextView password = layout.findViewById(R.id.tV_Password);

		// Open SQLite DB write permission
		db = handler.getWritableDatabase();

		// Add search email query to cursor
		Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME, null, " " + UsersSQLiteHandler.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

		while (cursor.moveToNext()) {
			if (cursor.isFirst()) {
				cursor.moveToFirst();

				// Store Password/Name associated with user email
				PhoneNumberHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLiteHandler.COLUMN_2_PHONE_NUMBER));
				TempPassword = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLiteHandler.COLUMN_4_PASSWORD));

				// Close cursor.
				cursor.close();
			}
		}
		handler.close();

		Button get = layout.findViewById(R.id.forgotGetButton);
		Button cancel = layout.findViewById(R.id.forgotCancelButton);

		get.setOnClickListener(view -> {
			String verifyPhone = phone.getText().toString();

			if(verifyPhone.equals(PhoneNumberHolder)) {
				password.setText(TempPassword);

				new android.os.Handler().postDelayed(() -> popwindow.dismiss(), 2000);
			} else {
				Toast.makeText(activity, "Phone Not Match", Toast.LENGTH_LONG).show();
			}
		});

		cancel.setOnClickListener(view -> {
			Toast.makeText(activity, "Action Canceled", Toast.LENGTH_SHORT).show();
			popwindow.dismiss();
		});
	}
}
