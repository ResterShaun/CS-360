package com.zybooks.rester_shaun_project_2;

/**
 * Shaun Rester CS-360 Final App Project
 */

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class RegisterActivity extends AppCompatActivity {

    Button RegisterButton, CancelButton;
    EditText NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
    SQLiteDatabase db;
    UsersSQLiteHandler handler;
    String F_Result = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        NameHolder = findViewById(R.id.eT_UserName);
        PhoneNumberHolder = findViewById(R.id.eT_PhoneNumber);
        EmailHolder = findViewById(R.id.eT_Email);
        PasswordHolder = findViewById(R.id.eT_Password);
        RegisterButton = findViewById(R.id.regSignupButton);
        CancelButton = findViewById(R.id.regCancelButton);
        handler = new UsersSQLiteHandler(this);

        // Add click listener to register forgotPasswordButton
        RegisterButton.setOnClickListener(view -> {
			String message = CheckEditTextNotEmpty();

			if (!EmptyHolder) {
				// Check if email already exists for DB
				CheckEmailAlreadyExists();
				// Empty editText fields after done inserting for DB
				EmptyEditTextAfterDataInsert();
			} else {
				// Display message for void fields then focus fields
				Toast.makeText(this, message, Toast.LENGTH_LONG).show();
			}
		});

		// Add click listener for addCancelButton
		CancelButton.setOnClickListener(view -> {
			// Navigate back to LoginActivity after cancel Register
			startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
			this.finish();
		});

	}

    // Register new user into DB
    public void InsertUserIntoDatabase(){
        	String name = NameHolder.getText().toString().trim();
        	String phone = PhoneNumberHolder.getText().toString().trim();
			String email = EmailHolder.getText().toString().trim();
			String pass = PasswordHolder.getText().toString().trim();

			User user = new User(name, phone, email, pass);
			handler.createUser(user);

            // Print message after done insertion.
            Toast.makeText(RegisterActivity.this,"User Registered Successfully", Toast.LENGTH_LONG).show();

            // navigate back to LoginActivity post register success message
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            this.finish();
    }

	// Check item description not void
	public String CheckEditTextNotEmpty() {
		// Get value for fields/storing to string variable
		String message = "";
		String name = NameHolder.getText().toString().trim();
		String phone = PhoneNumberHolder.getText().toString().trim();
		String email = EmailHolder.getText().toString().trim();
		String pass = PasswordHolder.getText().toString().trim();

		if (name.isEmpty()) {
			NameHolder.requestFocus();
			EmptyHolder = true;
			message = "User Name is Empty";
		} else if (phone.isEmpty()){
			PhoneNumberHolder.requestFocus();
			EmptyHolder = true;
			message = "User Phone is Empty";
		} else if (email.isEmpty()){
			EmailHolder.requestFocus();
			EmptyHolder = true;
			message = "User Email is Empty";
		} else if (pass.isEmpty()){
			PasswordHolder.requestFocus();
			EmptyHolder = true;
			message = "User Password is Empty";
		} else {
			EmptyHolder = false;
		}
		return message;
	}

    // Check user email does not currently exist in DB
    public void CheckEmailAlreadyExists(){
		String email = EmailHolder.getText().toString().trim();
		db = handler.getWritableDatabase();

        // Add search email query to cursor
        Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME, null, " " + UsersSQLiteHandler.COLUMN_3_EMAIL + "=?", new String[]{email}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // verify email exists/found
                F_Result = "Email Found";
                // Close cursor.
                cursor.close();
            }
        }
        handler.close();

        // Call method checking end result/insert data to DB
        CheckFinalCredentials();
    }

    // Check login credentials
    public void CheckFinalCredentials(){
        // Check if DB already has email stored
        if(F_Result.equalsIgnoreCase("Email Found"))
        {
            // Message displays if email exists
            Toast.makeText(RegisterActivity.this,"Email Already Exists",Toast.LENGTH_LONG).show();
        }
        else {
            // New email will be entered to DB
            InsertUserIntoDatabase();
        }
        F_Result = "Not_Found" ;
    }

    // Clear edittext once inserted to DB
    public void EmptyEditTextAfterDataInsert(){
        NameHolder.getText().clear();
        PhoneNumberHolder.getText().clear();
        EmailHolder.getText().clear();
        PasswordHolder.getText().clear();
    }

}
